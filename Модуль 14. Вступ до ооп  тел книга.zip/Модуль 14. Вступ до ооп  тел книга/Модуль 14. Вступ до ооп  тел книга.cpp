﻿#include <iostream>
#include <fstream>
#include <vector>
#include <cstring> 
#include <cctype>  
#include <algorithm>
using namespace std;
class Contact {
private:
    char* fullName;     
    string homePhone;
    string workPhone;
    string mobilePhone;
    string extraInfo;
public:
    Contact() : fullName(nullptr), homePhone(""), workPhone(""), mobilePhone(""), extraInfo("") {}
    Contact(const char* name, const string& home, const string& work,
        const string& mobile, const string& info)
        : homePhone(home), workPhone(work), mobilePhone(mobile), extraInfo(info) {
        fullName = new char[strlen(name) + 1];
        strcpy(fullName, name);
    }

    Contact(const Contact& other)
        : homePhone(other.homePhone), workPhone(other.workPhone),
        mobilePhone(other.mobilePhone), extraInfo(other.extraInfo) {
        fullName = new char[strlen(other.fullName) + 1];
        strcpy(fullName, other.fullName);
    }

    ~Contact() {
        delete[] fullName;
    }

    Contact& operator=(const Contact& other) {
        if (this != &other) {
            delete[] fullName;
            fullName = new char[strlen(other.fullName) + 1];
            strcpy(fullName, other.fullName);
            homePhone = other.homePhone;
            workPhone = other.workPhone;
            mobilePhone = other.mobilePhone;
            extraInfo = other.extraInfo;
        }
        return *this;
    }

    inline const char* getFullName() const { return fullName; 
    inline void setHomePhone(const string& phone) { homePhone = phone; }
    inline void setWorkPhone(const string& phone) { workPhone = phone; }
    inline void setMobilePhone(const string& phone) { mobilePhone = phone; }
    inline void setExtraInfo(const string& info) { extraInfo = info; }

    void print() const {
        cout << "ПІБ: " << fullName << endl;
        cout << "Домашній телефон: " << homePhone << endl;
        cout << "Робочий телефон: " << workPhone << endl;
        cout << "Мобільний телефон: " << mobilePhone << endl;
        cout << "Додаткова інформація: " << extraInfo << endl;
        cout << "--------------------------" << endl;
    }

    void saveToFile(ofstream& out) const {
        int len = strlen(fullName);
        out.write(reinterpret_cast<const char*>(&len), sizeof(len));
        out.write(fullName, len);
        writeStringToFile(out, homePhone);
        writeStringToFile(out, workPhone);
        writeStringToFile(out, mobilePhone);
        writeStringToFile(out, extraInfo);
    }

    void loadFromFile(ifstream& in) {
        int len;
        in.read(reinterpret_cast<char*>(&len), sizeof(len));
        fullName = new char[len + 1];
        in.read(fullName, len);
        fullName[len] = '\0';
        homePhone = readStringFromFile(in);
        workPhone = readStringFromFile(in);
        mobilePhone = readStringFromFile(in);
        extraInfo = readStringFromFile(in);
    }

private:
    void writeStringToFile(ofstream& out, const string& str) const {
        unsigned long size = str.size();
        out.write(reinterpret_cast<const char*>(&size), sizeof(size));
        out.write(str.c_str(), size);
    }

    string readStringFromFile(ifstream& in) {
        unsigned long size;
        in.read(reinterpret_cast<char*>(&size), sizeof(size));
        char* buffer = new char[size + 1];
        in.read(buffer, size);
        buffer[size] = '\0';
        string result(buffer);
        delete[] buffer;
        return result;
    }
};

void showMenu() {
    cout << "\n--- Телефонна книга ---\n";
    cout << "1. Додати контакт\n";
    cout << "2. Видалити контакт\n";
    cout << "3. Пошук за ПІБ\n";
    cout << "4. Показати всі контакти\n";
    cout << "5. Зберегти в файл\n";
    cout << "6. Завантажити з файлу\n";
    cout << "7. Вихід\n";
    cout << "Ваш вибір: ";
}

int main() {
    vector<Contact> contacts;
    int choice;

    do {
        showMenu();
        cin >> choice;
        cin.ignore(); 

        switch (choice) {
        case 1: {
            char name[256];
            string home, work, mobile, info;
            cout << "Введіть ПІБ: ";
            cin.getline(name, 256);
            cout << "Домашній телефон: ";
            cin >> home;
            cout << "Робочий телефон: ";
            cin >> work;
            cout << "Мобільний телефон: ";
            cin >> mobile;
            cin.ignore();
            cout << "Додаткова інформація: ";
            cin.getline(info.data(), 256);
            contacts.emplace_back(name, home, work, mobile, info);
            break;
        }
        case 2: {
            char name[256];
            cout << "Введіть ПІБ для видалення: ";
            cin.getline(name, 256);

            auto it = remove_if(contacts.begin(), contacts.end(),
                [&](const Contact& c) {
                    return strcmp(c.getFullName(), name) == 0;
                });
            if (it != contacts.end()) {
                contacts.erase(it, contacts.end());
                cout << "Контакт видалено.\n";
            }
            else {
                cout << "Контакт не знайдено.\n";
            }
            break;
        }

        case 3: {
            char name[256];
            cout << "Введіть ПІБ для пошуку: ";
            cin.getline(name, 256);

            bool found = false;
            for (const auto& contact : contacts) {
                if (strcmp(contact.getFullName(), name) == 0) {
                    contact.print();
                    found = true;
                }
            }
            if (!found) {
                cout << "Контакт не знайдено.\n";
            }
            break;
        }

        case 4:
            if (contacts.empty()) {
                cout << "Телефонна книга порожня.\n";
            }
            else {
                for (const auto& contact : contacts) {
                    contact.print();
                }
            }
            break;

        case 5: {
            ofstream outFile("contacts.dat", ios::binary);
            if (outFile.is_open()) {
                int count = contacts.size();
                outFile.write(reinterpret_cast<const char*>(&count), sizeof(count));
                for (const auto& contact : contacts) {
                    contact.saveToFile(outFile);
                }
                outFile.close();
                cout << "Контакти збережено у файл 'contacts.dat'.\n";
            }
            else {
                cout << "Не вдалося відкрити файл для запису.\n";
            }
            break;
        }

        case 6: {
            contacts.clear();
            ifstream inFile("contacts.dat", ios::binary);
            if (inFile.is_open()) {
                int count;
                inFile.read(reinterpret_cast<char*>(&count), sizeof(count));
                for (int i = 0; i < count; ++i) {
                    Contact contact;
                    contact.loadFromFile(inFile);
                    contacts.push_back(contact);
                }
                inFile.close();
                cout << "Контакти завантажено з файлу.\n";
            }
            else {
                cout << "Файл не знайдено або порожній.\n";
            }
            break;
        }

        case 7:
            cout << "Вихід...\n";
            break;

        default:
            cout << "Невірний вибір. Спробуйте ще раз.\n";
        }

    } while (choice != 7);

    return 0;
}