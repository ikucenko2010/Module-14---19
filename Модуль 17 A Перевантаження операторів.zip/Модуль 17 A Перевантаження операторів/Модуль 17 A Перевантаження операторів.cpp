﻿#include <cstring>

class String {
private:
    char* data;
    size_t size;

public:
    String(const char* str = nullptr) {
        if (str == nullptr) {
            size = 0;
            data = new char[1];
            data[0] = '\0';
        }
        else {
            size = std::strlen(str);
            data = new char[size + 1];
            std::strcpy(data, str);
        }
    }

    String(const String& other) {
        size = other.size;
        data = new char[size + 1];
        std::strcpy(data, other.data);
    }

    String& operator=(const String& other) {
        if (this != &other) {
            delete[] data;
            size = other.size;
            data = new char[size + 1];
            std::strcpy(data, other.data);
        }
        return *this;
    }

    String(String&& other) noexcept {
        data = other.data;
        size = other.size;
        other.data = nullptr;
        other.size = 0;
    }

    String& operator=(String&& other) noexcept {
        if (this != &other) {
            delete[] data;
            data = other.data;
            size = other.size;
            other.data = nullptr;
            other.size = 0;
        }
        return *this;
    }

    ~String() {
        delete[] data;
    }
};