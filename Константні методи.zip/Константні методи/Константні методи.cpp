﻿#include <iostream>
#include <string>
#include <vector>

class Worker {
private:
    std::string fullName;
    std::string position;
    int hireYear;
    double salary;

public:
    explicit Worker(const std::string& name = "", const std::string& pos = "",
        int year = 2020, double sal = 0.0)
        : fullName(name), position(pos), hireYear(year), salary(sal) {}

    std::string getFullName() const { return fullName; }
    std::string getPosition() const { return position; }
    int getHireYear() const { return hireYear; }
    double getSalary() const { return salary; }

    void display() const {
        std::cout << "Name: " << fullName
            << ", Position: " << position
            << ", Hire Year: " << hireYear
            << ", Salary: " << salary << std::endl;
    }
};

int main() {
    std::vector<Worker> workers = {
        Worker("Ivanov Ivan Ivanovich", "Engineer", 2018, 45000),
        Worker("Petrov Petr Petrovich", "Manager", 2020, 60000),
        Worker("Sidorov Sidr Sidorovich", "Engineer", 2015, 50000),
        Worker("Kovalenko Olena", "Analyst", 2021, 35000),
        Worker("Bondarenko Mykola", "Manager", 2017, 65000)
    };

    int currentYear = 2024;
    int minExperience, minSalary;
    std::string targetPosition;

    std::cout << "Enter minimum years of experience: ";
    std::cin >> minExperience;
    std::cout << "Enter minimum salary: ";
    std::cin >> minSalary;
    std::cin.ignore();
    std::cout << "Enter position to search: ";
    std::getline(std::cin, targetPosition);

    std::cout << "\nWorkers with experience > " << minExperience << " years:\n";
    for (const auto& w : workers) {
        if (currentYear - w.getHireYear() > minExperience) {
            w.display();
        }
    }

    std::cout << "\nWorkers with salary > " << minSalary << ":\n";
    for (const auto& w : workers) {
        if (w.getSalary() > minSalary) {
            w.display();
        }
    }

    std::cout << "\nWorkers with position '" << targetPosition << "':\n";
    for (const auto& w : workers) {
        if (w.getPosition() == targetPosition) {
            w.display();
        }
    }

    return 0;
}