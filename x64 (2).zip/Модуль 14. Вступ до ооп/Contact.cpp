// Contact.cpp
#include "Contact.h"
#include <cstring>
#include <cstdlib>

Contact::Contact() {
    fullName = new char[1];
    fullName[0] = '\0';
    homePhone = new char[1];
    homePhone[0] = '\0';
    workPhone = new char[1];
    workPhone[0] = '\0';
    mobilePhone = new char[1];
    mobilePhone[0] = '\0';
    info = new char[1];
    info[0] = '\0';
}

Contact::Contact(const char* name, const char* home, const char* work, const char* mobile, const char* info) {
    fullName = new char[strlen(name) + 1];
    strcpy(fullName, name);
    homePhone = new char[strlen(home) + 1];
    strcpy(homePhone, home);
    workPhone = new char[strlen(work) + 1];
    strcpy(workPhone, work);
    mobilePhone = new char[strlen(mobile) + 1];
    strcpy(mobilePhone, mobile);
    this->info = new char[strlen(info) + 1];
    strcpy(this->info, info);
}

Contact::Contact(const Contact& other) {
    fullName = new char[strlen(other.fullName) + 1];
    strcpy(fullName, other.fullName);
    homePhone = new char[strlen(other.homePhone) + 1];
    strcpy(homePhone, other.homePhone);
    workPhone = new char[strlen(other.workPhone) + 1];
    strcpy(workPhone, other.workPhone);
    mobilePhone = new char[strlen(other.mobilePhone) + 1];
    strcpy(mobilePhone, other.mobilePhone);
    info = new char[strlen(other.info) + 1];
    strcpy(info, other.info);
}

Contact::~Contact() {
    delete[] fullName;
    delete[] homePhone;
    delete[] workPhone;
    delete[] mobilePhone;
    delete[] info;
}

void Contact::print() const {
    std::cout << "ϲ�: " << fullName << std::endl;
    std::cout << "�������� �������: " << homePhone << std::endl;
    std::cout << "������� �������: " << workPhone << std::endl;
    std::cout << "�������� �������: " << mobilePhone << std::endl;
    std::cout << "��������� ����������: " << info << std::endl;
    std::cout << "-----------------------------" << std::endl;
}

void Contact::saveToFile(std::ofstream& fout) const {
    fout << fullName << std::endl;
    fout << homePhone << std::endl;
    fout << workPhone << std::endl;
    fout << mobilePhone << std::endl;
    fout << info << std::endl;
}

void Contact::loadFromFile(std::ifstream& fin) {
    char buffer[256];

    fin.getline(buffer, 256);
    delete[] fullName;
    fullName = new char[strlen(buffer) + 1];
    strcpy(fullName, buffer);

    fin.getline(buffer, 256);
    delete[] homePhone;
    homePhone = new char[strlen(buffer) + 1];
    strcpy(homePhone, buffer);

    fin.getline(buffer, 256);
    delete[] workPhone;
    workPhone = new char[strlen(buffer) + 1];
    strcpy(workPhone, buffer);

    fin.getline(buffer, 256);
    delete[] mobilePhone;
    mobilePhone = new char[strlen(buffer) + 1];
    strcpy(mobilePhone, buffer);

    fin.getline(buffer, 256);
    delete[] info;
    info = new char[strlen(buffer) + 1];
    strcpy(info, buffer);
}