#pragma once
#pragma once
#include <iostream>
#include <fstream>

class Contact {
private:
    char* fullName;
    char* homePhone;
    char* workPhone;
    char* mobilePhone;
    char* info;

public:
    Contact();
    Contact(const char* name, const char* home, const char* work, const char* mobile, const char* info);
    Contact(const Contact& other);
    ~Contact();

    inline void setFullName(const char* name) { std::strcpy(fullName, name); }
    inline void setHomePhone(const char* phone) { std::strcpy(homePhone, phone); }
    inline void setWorkPhone(const char* phone) { std::strcpy(workPhone, phone); }
    inline void setMobilePhone(const char* phone) { std::strcpy(mobilePhone, phone); }
    inline void setInfo(const char* i) { std::strcpy(info, i); }

    inline const char* getFullName() const { return fullName; }
    inline const char* getHomePhone() const { return homePhone; }
    inline const char* getWorkPhone() const { return workPhone; }
    inline const char* getMobilePhone() const { return mobilePhone; }
    inline const char* getInfo() const { return info; }

    void print() const;
    void saveToFile(std::ofstream& fout) const;
    void loadFromFile(std::ifstream& fin);
};