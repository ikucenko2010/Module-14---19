﻿#include <iostream>
#include <vector>
#include <fstream>
#include "Contact.h"

using namespace std;

void addContact(vector<Contact>& contacts);
void deleteContact(vector<Contact>& contacts);
void searchContact(const vector<Contact>& contacts);
void showAllContacts(const vector<Contact>& contacts);
void saveToFile(const vector<Contact>& contacts);
void loadFromFile(vector<Contact>& contacts);

int main() {
    vector<Contact> contacts;
    int choice;

    do {
        cout << "\n===== Телефонна книга =====\n";
        cout << "1. Додати абонента\n";
        cout << "2. Видалити абонента\n";
        cout << "3. Шукати абонента\n";
        cout << "4. Показати всіх абонентів\n";
        cout << "5. Зберегти в файл\n";
        cout << "6. Завантажити з файлу\n";
        cout << "7. Вихід\n";
        cout << "Виберіть опцію: ";
        cin >> choice;
        cin.ignore();

        switch (choice) {
        case 1: addContact(contacts); break;
        case 2: deleteContact(contacts); break;
        case 3: searchContact(contacts); break;
        case 4: showAllContacts(contacts); break;
        case 5: saveToFile(contacts); break;
        case 6: loadFromFile(contacts); break;
        case 7: cout << "Вихід...\n"; break;
        default: cout << "Невірний вибір!\n";
        }
    } while (choice != 7);

    return 0;
}

void addContact(vector<Contact>& contacts) {
    char name[256], home[20], work[20], mobile[20], info[256];

    cout << "Введіть ПІБ: "; cin.getline(name, 256);
    cout << "Домашній телефон: "; cin.getline(home, 20);
    cout << "Робочий телефон: "; cin.getline(work, 20);
    cout << "Мобільний телефон: "; cin.getline(mobile, 20);
    cout << "Додаткова інформація: "; cin.getline(info, 256);

    contacts.emplace_back(name, home, work, mobile, info);
    cout << "Контакт доданий.\n";
}

void deleteContact(vector<Contact>& contacts) {
    char name[256];
    cout << "Введіть ПІБ для видалення: "; cin.getline(name, 256);

    for (auto it = contacts.begin(); it != contacts.end(); ++it) {
        if (strcmp(it->getFullName(), name) == 0) {
            contacts.erase(it);
            cout << "Контакт видалений.\n";
            return;
        }
    }
    cout << "Контакт не знайдено.\n";
}

void searchContact(const vector<Contact>& contacts) {
    char name[256];
    cout << "Введіть ПІБ для пошуку: "; cin.getline(name, 256);

    for (const auto& contact : contacts) {
        if (strcmp(contact.getFullName(), name) == 0) {
            contact.print();
            return;
        }
    }
    cout << "Контакт не знайдено.\n";
}

void showAllContacts(const vector<Contact>& contacts) {
    if (contacts.empty()) {
        cout << "Телефонна книга порожня.\n";
        return;
    }
    for (const auto& contact : contacts) {
        contact.print();
    }
}

void saveToFile(const vector<Contact>& contacts) {
    ofstream fout("phonebook.txt");
    int size = contacts.size();
    fout << size << endl;

    for (const auto& contact : contacts) {
        contact.saveToFile(fout);
    }
    fout.close();
    cout << "Контакти збережені.\n";
}

void loadFromFile(vector<Contact>& contacts) {
    ifstream fin("phonebook.txt");
    if (!fin.is_open()) {
        cout << "Файл не знайдено.\n";
        return;
    }

    int size;
    fin >> size;
    fin.ignore();

    contacts.clear();
    for (int i = 0; i < size; ++i) {
        Contact c;
        c.loadFromFile(fin);
        contacts.push_back(c);
    }
    fin.close();
    cout << "Контакти завантажені.\n";
}